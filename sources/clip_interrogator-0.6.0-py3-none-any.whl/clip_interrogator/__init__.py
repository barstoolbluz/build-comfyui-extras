from .clip_interrogator import Config, Interrogator, LabelTable, list_caption_models, list_clip_models, load_list

__version__ = '0.6.0'
__author__ = 'pharmapsychotic'