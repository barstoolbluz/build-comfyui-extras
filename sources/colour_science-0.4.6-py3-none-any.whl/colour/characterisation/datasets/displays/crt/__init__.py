from .primaries import MSDS_DISPLAY_PRIMARIES_CRT

__all__ = [
    "MSDS_DISPLAY_PRIMARIES_CRT",
]
