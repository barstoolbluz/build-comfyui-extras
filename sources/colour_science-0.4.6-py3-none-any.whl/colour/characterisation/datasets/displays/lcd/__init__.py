from .primaries import MSDS_DISPLAY_PRIMARIES_LCD

__all__ = [
    "MSDS_DISPLAY_PRIMARIES_LCD",
]
